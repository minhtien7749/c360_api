package c360.model;

public class DepDtlFact {
private String cif;
private String branch;
private String crcd;
private String ytdAvgBalAmt;
private String ytdAvgBalAmtTc;
private String ytdOnlAvgBalAmt;
private String ytdOnlAvgBalAmtTc;
private String dlyBalAmt;
private String dlyBalAmtTc;
private String dlyOnBalAmt;
private String dlyOnBalAmtTc;
private String qlyBalAmt;
private String qlyBalAmtTc;
private String qlyOnBalAmt;
private String qlyOnBalAmtTc;
private String ytdNiiAmt;
private String ytdNimAmt;
private String cob_dt;

// có mã tiền lẫn lãi,

public String getCrcd() {
	return crcd;
}




public DepDtlFact(String cif, String branch, String crcd, String ytdAvgBalAmt, String ytdAvgBalAmtTc,
		String ytdOnlAvgBalAmt, String ytdOnlAvgBalAmtTc, String dlyBalAmt, String dlyBalAmtTc, String dlyOnBalAmt,
		String dlyOnBalAmtTc, String qlyBalAmt, String qlyBalAmtTc, String qlyOnBalAmt, String qlyOnBalAmtTc,
		String ytdNiiAmt, String ytdNimAmt, String cob_dt) {
	super();
	this.cif = cif;
	this.branch = branch;
	this.crcd = crcd;
	this.ytdAvgBalAmt = ytdAvgBalAmt;
	this.ytdAvgBalAmtTc = ytdAvgBalAmtTc;
	this.ytdOnlAvgBalAmt = ytdOnlAvgBalAmt;
	this.ytdOnlAvgBalAmtTc = ytdOnlAvgBalAmtTc;
	this.dlyBalAmt = dlyBalAmt;
	this.dlyBalAmtTc = dlyBalAmtTc;
	this.dlyOnBalAmt = dlyOnBalAmt;
	this.dlyOnBalAmtTc = dlyOnBalAmtTc;
	this.qlyBalAmt = qlyBalAmt;
	this.qlyBalAmtTc = qlyBalAmtTc;
	this.qlyOnBalAmt = qlyOnBalAmt;
	this.qlyOnBalAmtTc = qlyOnBalAmtTc;
	this.ytdNiiAmt = ytdNiiAmt;
	this.ytdNimAmt = ytdNimAmt;
	this.cob_dt = cob_dt;
}




public void setCrcd(String crcd) {
	this.crcd = crcd;
}

public String getCif() {
	return cif;
}

public void setCif(String cif) {
	this.cif = cif;
}

public String getBranch() {
	return branch;
}
public void setBranch(String branch) {
	this.branch = branch;
}
public String getYtdAvgBalAmt() {
	return ytdAvgBalAmt;
}
public void setYtdAvgBalAmt(String ytdAvgBalAmt) {
	this.ytdAvgBalAmt = ytdAvgBalAmt;
}

public String getYtdOnlAvgBalAmt() {
	return ytdOnlAvgBalAmt;
}

public void setYtdOnlAvgBalAmt(String ytdOnlAvgBalAmt) {
	this.ytdOnlAvgBalAmt = ytdOnlAvgBalAmt;
}

public String getDlyBalAmt() {
	return dlyBalAmt;
}

public void setDlyBalAmt(String dlyBalAmt) {
	this.dlyBalAmt = dlyBalAmt;
}

public String getYtdNiiAmt() {
	return ytdNiiAmt;
}

public void setYtdNiiAmt(String ytdNiiAmt) {
	this.ytdNiiAmt = ytdNiiAmt;
}

public String getYtdNimAmt() {
	return ytdNimAmt;
}

public void setYtdNimAmt(String ytdNimAmt) {
	this.ytdNimAmt = ytdNimAmt;
}


public String getYtdAvgBalAmtTc() {
	return ytdAvgBalAmtTc;
}

public void setYtdAvgBalAmtTc(String ytdAvgBalAmtTc) {
	this.ytdAvgBalAmtTc = ytdAvgBalAmtTc;
}

public String getYtdOnlAvgBalAmtTc() {
	return ytdOnlAvgBalAmtTc;
}

public void setYtdOnlAvgBalAmtTc(String ytdOnlAvgBalAmtTc) {
	this.ytdOnlAvgBalAmtTc = ytdOnlAvgBalAmtTc;
}

public String getDlyBalAmtTc() {
	return dlyBalAmtTc;
}

public void setDlyBalAmtTc(String dlyBalAmtTc) {
	this.dlyBalAmtTc = dlyBalAmtTc;
}

public String getCob_dt() {
	return cob_dt;
}

public void setCob_dt(String cob_dt) {
	this.cob_dt = cob_dt;
}

public String getDlyOnBalAmt() {
	return dlyOnBalAmt;
}

public void setDlyOnBalAmt(String dlyOnBalAmt) {
	this.dlyOnBalAmt = dlyOnBalAmt;
}

public String getDlyOnBalAmtTc() {
	return dlyOnBalAmtTc;
}

public void setDlyOnBalAmtTc(String dlyOnBalAmtTc) {
	this.dlyOnBalAmtTc = dlyOnBalAmtTc;
}

public String getQlyBalAmt() {
	return qlyBalAmt;
}

public void setQlyBalAmt(String qlyBalAmt) {
	this.qlyBalAmt = qlyBalAmt;
}

public String getQlyBalAmtTc() {
	return qlyBalAmtTc;
}

public void setQlyBalAmtTc(String qlyBalAmtTc) {
	this.qlyBalAmtTc = qlyBalAmtTc;
}

public String getQlyOnBalAmt() {
	return qlyOnBalAmt;
}

public void setQlyOnBalAmt(String qlyOnBalAmt) {
	this.qlyOnBalAmt = qlyOnBalAmt;
}

public String getQlyOnBalAmtTc() {
	return qlyOnBalAmtTc;
}

public void setQlyOnBalAmtTc(String qlyOnBalAmtTc) {
	this.qlyOnBalAmtTc = qlyOnBalAmtTc;
}



}
