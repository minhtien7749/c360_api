package c360.service;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import c360.database.*;
import c360.model.*;
import c360.service.*;

public class ImportExportRespond {
    public static ArrayList<ImportExport> getRespond(InputRequestCorporate request) {
        ArrayList<ImportExport> importExports = new ArrayList<>();
        String sql = "select *\n" +
                "from customer360.c360_bcl_cor_imp_exp %s";
        String sqlBranch = "select *\n" +
                "from customer360.c360_bcl_cor_imp_exp %s";
        String cifName = "";
        if (request.getCif() != null){
            cifName = "acn";
        } else {cifName = "tax_id";}


        try {
            JdbcUtil jdbc = new JdbcUtil();
            SqlQuery sqlObj = new SqlQuery(request, sql, sqlBranch, "c360_bcl_cor_imp_exp");
            Connection c = jdbc.getConnection();
            boolean hasGroupBy = false;
            PreparedStatement stm = sqlObj.SQLPrepareFinal(cifName, c, hasGroupBy);
            ResultSet rc = stm.executeQuery();
            while (rc.next()){
                String tax_id = rc.getString ("tax_id");
                String branch = rc.getString ("branch");
                String acn = rc.getString ("acn");
                String corp_name = rc.getString ("corp_name");
                String address = rc.getString ("address");
                String phone = rc.getString ("phone");
                BigDecimal mtd_import_amt_usd = rc.getBigDecimal ("mtd_import_amt_usd");
                BigDecimal mtd_export_amt_usd = rc.getBigDecimal ("mtd_export_amt_usd");
                BigDecimal ytd_total_import_amt_usd = rc.getBigDecimal ("ytd_total_import_amt_usd");
                BigDecimal ytd_total_exp_amt_usd = rc.getBigDecimal ("ytd_total_exp_amt_usd");
                String cob_dt = rc.getString ("cob_dt");
                importExports.add(new ImportExport(tax_id,branch,acn,corp_name,address,phone,mtd_import_amt_usd,mtd_export_amt_usd,
                        ytd_total_import_amt_usd,ytd_total_exp_amt_usd,cob_dt));
            }
            c.close();
        }
        catch (SQLException e){
            System.out.println(e.getErrorCode());
        }
        for (ImportExport cus : importExports){
            System.out.println(cus.toString());
        }
        return importExports;

    }

    public static void main(String[] args) {
        InputRequestCorporate request = new InputRequestCorporate("1","1","1",null,"2022-01-01",null,null,null, "123456");
        ArrayList<ImportExport> a = getRespond(request);
    }


}