package dao.request;

public class LnDtlFactRequest {
    private String requestId;
    private String cif;
    private String branch;
    private String fromDate;
    private String toDate;
}
