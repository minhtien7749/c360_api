package query;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import dao.request.DepDltFactRequest;

public class DepDltFactQuery {
	private final  String SQL_TEMPLATE = "select acn,"
			+ "SUM(YTD_AVG_LDGR_BAL_AMT_IN_LC) as ytdAvgBalAmt, "
			+ "SUM(YTD_AVG_LDGR_BAL_AMT_IN_TC) as ytdAvgBalAmtTc, "
			
			+ "sum(case when zchanid in ('78','77') then YTD_AVG_LDGR_BAL_AMT_IN_LC end) as ytdOnlAvgBalAmt,"
			+ "sum(case when zchanid in ('78','77') then YTD_AVG_LDGR_BAL_AMT_IN_TC end) as ytdOnlAvgBalAmtTc,"
			
			+ "SUM(dly_ldgr_bal_amt_in_lc) as dlyBalAmt, "
			+ "SUM(dly_ldgr_bal_amt_in_tc) as dlyBalAmtTc, "
			
			+ "sum(case when zchanid in ('78','77') then dly_ldgr_bal_amt_in_lc end) as dlyOnBalAmt,"
			+ "sum(case when zchanid in ('78','77') then dly_ldgr_bal_amt_in_lc end) as dlyOnBalAmtTc,"
			
			+"SUM(QTD_AVG_LDGR_BAL_AMT_IN_LC) as qtdAvgBalAmt,"
			+ "SUM(QTD_AVG_LDGR_BAL_AMT_IN_TC) as qtdAvgBalAmtTc, "
			
			+ "sum(case when zchanid in ('78','77') then QTD_AVG_LDGR_BAL_AMT_IN_LC end) as qtdOnlAvgBalAmt,"
			+ "sum(case when zchanid in ('78','77') then QTD_AVG_LDGR_BAL_AMT_IN_TC end) as qtdOnlAvgBalAmtTc,"
			
			+ "SUM(ytd_nii_alco_amt_in_lc) as ytdNiiAmt,"
			+ "SUM(ytd_nii_alco_amt_in_lc) / SUM(ytd_avg_ldgr_bal_amt_in_lc) as ytdNimAmt,";
	

    private DepDltFactRequest request;

    public DepDltFactQuery(DepDltFactRequest request) {
        this.request = request;
    }


    public PreparedStatement acn_only(Connection c){
        String sql_filling = " cob_dt from customer360.c360_depst_dtls_fact where cob_dt >= ? and cob_dt <= ? and type <> '2109'  and acn = ? group by acn,cob_dt ";
        String sql_final = (this.SQL_TEMPLATE+ sql_filling);
        PreparedStatement statement = null;
        try {
            System.out.println("acn_only sc");
            statement = c.prepareStatement(sql_final);
            int parameterIndex = 1;
            statement.setString(parameterIndex ++, request.getFromDate());
            statement.setString(parameterIndex ++, request.getToDate());
            statement.setString(parameterIndex ++, request.getCif());
//            System.out.println(statement.toString());
                                              
        } catch (SQLException e) {                          
            throw new RuntimeException(e);                                   
        }
        return statement;
    }
    
    public PreparedStatement acn_irn_only(Connection c){
        String sql_filling = "SUM(YTD_AVG_LDGR_BAL_AMT_IN_LC) as irnGrpYtd, SUM(dly_ldgr_bal_amt_in_lc) as irnGrpDly,cob_dt"
        		+ "from customer360.c360_depst_dtls_fact where cob_dt >= ? and cob_dt <= ?  and type <> '2109'  and acn = ? and cast(irn as double) between ? and ? group by acn,cob_dt";
           
        String sql_final = (this.SQL_TEMPLATE+ sql_filling);
        PreparedStatement statement = null;
        try {
            System.out.println(" acn_irn_only sc");
            statement = c.prepareStatement(sql_final);
            int parameterIndex = 1;
            statement.setString(parameterIndex ++, request.getFromDate());
            statement.setString(parameterIndex ++, request.getToDate());
            statement.setString(parameterIndex ++, request.getCif());
            statement.setString(parameterIndex ++, request.getIrn_str());
            statement.setString(parameterIndex ++, request.getIrn_end());
            System.out.println(statement.toString());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return statement;
    }  
  
    
    //final_form
    public PreparedStatement acn_crcd_only(Connection c){
        String sql_filling = " crcd,cob_dt from customer360.c360_depst_dtls_fact where cob_dt >= ? and cob_dt <= ? and type <> '2109'  and acn = ? and crcd in (%s) group by acn,crcd,cob_dt";
        String sql_filling_2 = " crcd,cob_dt from customer360.c360_depst_dtls_fact where cob_dt >= ? and cob_dt <= ? and type <> '2109'  and acn = ? group by acn,crcd,cob_dt";
        PreparedStatement statement = null;
        try {
        	if (request.getCrcd().equals("1")) {
        	String sql_final = String.format(this.SQL_TEMPLATE+sql_filling_2);
            statement = c.prepareStatement(sql_final);
            int parameterIndex = 1;
            statement.setString(parameterIndex ++, request.getFromDate());
            statement.setString(parameterIndex ++, request.getToDate());
            statement.setString(parameterIndex ++, request.getCif());
        	}else {
            StringBuilder placeholdersBuilder = new StringBuilder();
            for (int i = 0; i < request.getCrcd().size(); i++) {
                placeholdersBuilder.append("?");
                if (i < request.getCrcd().size() - 1) {
                    placeholdersBuilder.append(",");
                }
            }
            String placeholders = placeholdersBuilder.toString();
            String sql_final = String.format(this.SQL_TEMPLATE +sql_filling,placeholders);
            
            System.out.println("acn_crcd_only sc");
            statement = c.prepareStatement(sql_final);
            int parameterIndex = 1;
            statement.setString(parameterIndex ++, request.getFromDate());
            statement.setString(parameterIndex ++, request.getToDate());
            statement.setString(parameterIndex ++, request.getCif());
            
            for (int i = 0; i < request.getCrcd().size(); i++) {
                statement.setString(parameterIndex++, request.getCrcd().get(i));
            }
            System.out.println(statement.toString());
        	}
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return statement;
    }  
    
    // cần sửa
    public PreparedStatement acn_irn_crcd_only(Connection c){
        String sql_filling = "SUM(YTD_AVG_LDGR_BAL_AMT_IN_LC) as irnGrpYtd, SUM(dly_ldgr_bal_amt_in_lc) as irnGrpDly, cob_dt from customer360.c360_depst_dtls_fact where cob_dt >= ? and cob_dt <= ? and type <> '2109'  and acn = ? and crcd in (%s) and irn <= ? and irn >= ? group by acn,crcd,cob_dt ";
           
        String sql = (this.SQL_TEMPLATE+ sql_filling);
        PreparedStatement statement = null;
        try {
        	
            StringBuilder placeholdersBuilder = new StringBuilder();
            for (int i = 0; i < request.getCrcd().size(); i++) {
                placeholdersBuilder.append("?");
                if (i < request.getCrcd().size() - 1) {
                    placeholdersBuilder.append(",");
                }
            }
            String placeholders = placeholdersBuilder.toString();
            String sql_final = String.format(sql,placeholders);
            System.out.println("acn_irn_crcd_only sc");
            statement = c.prepareStatement(sql_final);
            int parameterIndex = 1;
            statement.setString(parameterIndex ++, request.getFromDate());
            statement.setString(parameterIndex ++, request.getToDate());
            statement.setString(parameterIndex ++, request.getCif());
            statement.setString(parameterIndex ++, request.getBranch());
            
            for (int i = 0; i < request.getCrcd().size(); i++) {
                statement.setString(parameterIndex++, request.getCrcd().get(i));
            }
            
            statement.setString(parameterIndex ++, request.getIrn_str());
            statement.setString(parameterIndex ++, request.getIrn_end());
            System.out.println(statement.toString());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return statement;
    }       
    public PreparedStatement acn_branch_only(Connection c){
        String sql_filling = "cob_dt,boo as branch from customer360.c360_depst_dtls_fact where cob_dt >= ? and cob_dt <= ? and type <> '2109'  and acn = ? and substring(boo,1,3) = ? group by acn,boo,cob_dt ";
           
        String sql_final = (this.SQL_TEMPLATE+ sql_filling);
        PreparedStatement statement = null;
        try {
            System.out.println("sc");
            statement = c.prepareStatement(sql_final);
            int parameterIndex = 1;
            statement.setString(parameterIndex ++, request.getFromDate());
            statement.setString(parameterIndex ++, request.getToDate());
            statement.setString(parameterIndex ++, request.getCif());
            statement.setString(parameterIndex ++, request.getBranch());
            System.out.println(statement.toString());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return statement;
    }
    
    public PreparedStatement acn_branch_irn_only(Connection c){
        String sql_filling = "SUM(YTD_AVG_LDGR_BAL_AMT_IN_LC) as irnGrpYtd, SUM(dly_ldgr_bal_amt_in_lc) as irnGrpDly,boo as branch,cob_dt from customer360.c360_depst_dtls_fact where cob_dt >= ? and cob_dt <= ? and type <> '2109'  and acn = ? and substring(boo,1,3) = ? and irn <= ? and  irn >= ? group by acn,boo,cob_dt ";
           
        String sql_final = (this.SQL_TEMPLATE+ sql_filling);
        PreparedStatement statement = null;
        try {
            System.out.println("sc");
            statement = c.prepareStatement(sql_final);
            int parameterIndex = 1;
            statement.setString(parameterIndex ++, request.getFromDate());
            statement.setString(parameterIndex ++, request.getToDate());
            statement.setString(parameterIndex ++, request.getCif());
            statement.setString(parameterIndex ++, request.getBranch());
            statement.setString(parameterIndex ++, request.getIrn_str());
            statement.setString(parameterIndex ++, request.getIrn_end());
            System.out.println(statement.toString());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return statement;
    }
    public PreparedStatement acn_branch_crcd_only(Connection c){
        String sql_filling = "crcd,boo as branch,cob_dt from customer360.c360_depst_dtls_fact where cob_dt >= ? and cob_dt <= ? and type <> '2109'  and acn = ? and substring(boo,1,3) = ? and crcd in (%s) group by acn,crcd,boo,cob_dt ";
           
        PreparedStatement statement = null;
        try {
        	
            StringBuilder placeholdersBuilder = new StringBuilder();
            for (int i = 0; i < request.getCrcd().size(); i++) {
                placeholdersBuilder.append("?");
                if (i < request.getCrcd().size() - 1) {
                    placeholdersBuilder.append(",");
                }
            }
            String placeholders = placeholdersBuilder.toString();
            String sql_final = String.format(this.SQL_TEMPLATE +sql_filling,placeholders);
        	
            System.out.println("sc");
            statement = c.prepareStatement(sql_final);
            int parameterIndex = 1;
            statement.setString(parameterIndex ++, request.getFromDate());
            statement.setString(parameterIndex ++, request.getToDate());
            statement.setString(parameterIndex ++, request.getCif());
            statement.setString(parameterIndex ++, request.getBranch());
            
            for (int i = 0; i < request.getCrcd().size(); i++) {
                statement.setString(parameterIndex++, request.getCrcd().get(i));
            }
            
            System.out.println(statement.toString());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return statement;
    }
    public PreparedStatement acn_branch_irn_crcd_only(Connection c){
        String sql_filling = "SUM(YTD_AVG_LDGR_BAL_AMT_IN_LC) as irnGrpYtd, SUM(dly_ldgr_bal_amt_in_lc) as irnGrpDly,crcd,boo as branch,crcd,ccob_dt from customer360.c360_depst_dtls_fact where cob_dt >= ? and cob_dt <= ? and type <> '2109'  and acn = ? and substring(boo,1,3) = ? and crcd in (%s) and irn <= ? and irn >= ? group by acn,crcd,boo,cob_dt ";
         
        PreparedStatement statement = null;
        try {
            StringBuilder placeholdersBuilder = new StringBuilder();
            for (int i = 0; i < request.getCrcd().size(); i++) {
                placeholdersBuilder.append("?");
                if (i < request.getCrcd().size() - 1) {
                    placeholdersBuilder.append(",");
                }
            }
            String placeholders = placeholdersBuilder.toString();
            String sql_final = String.format(this.SQL_TEMPLATE +sql_filling,placeholders);
            
            System.out.println("sc");
            statement = c.prepareStatement(sql_final);
            int parameterIndex = 1;
            statement.setString(parameterIndex ++, request.getFromDate());
            statement.setString(parameterIndex ++, request.getToDate());
            statement.setString(parameterIndex ++, request.getCif());
            statement.setString(parameterIndex ++, request.getBranch());
            
            for (int i = 0; i < request.getCrcd().size(); i++) {
                statement.setString(parameterIndex++, request.getCrcd().get(i));
            }
            
            statement.setString(parameterIndex ++, request.getIrn_str());
            statement.setString(parameterIndex ++, request.getIrn_end());
            System.out.println(statement.toString());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return statement;
    }
// thêm grp 
    
    
    public PreparedStatement acn_only_grp(Connection c){
        String sql_filling = " cob_dt from customer360.c360_depst_dtls_fact where cob_dt >= ? and cob_dt <= ? and type <> '2109'  and acn = ? and grp in (?) group by acn,cob_dt ";
        String sql_final = (this.SQL_TEMPLATE+ sql_filling);
        PreparedStatement statement = null;
        try {
            System.out.println("acn_only sc");
            statement = c.prepareStatement(sql_final);
            int parameterIndex = 1;
            statement.setString(parameterIndex ++, request.getFromDate());
            statement.setString(parameterIndex ++, request.getToDate());
            statement.setString(parameterIndex ++, request.getCif());
            if(request.getGrp().equals("CASA")) {
            	String getGrp = request.getGrp();
            	getGrp = "DDA','SAV";
            statement.setString(parameterIndex ++,getGrp);
            } 
            if(request.getGrp().equals("FD")) {
            	String getGrp = request.getGrp();
            	getGrp = "CD";
            statement.setString(parameterIndex ++, getGrp);
            }
//            System.out.println(statement.toString());
                                              
        } catch (SQLException e) {                          
            throw new RuntimeException(e);                                   
        }
        return statement;
    }
    
    public PreparedStatement acn_irn_grp_only(Connection c){
        String sql_filling = "SUM(ytd_ldgr_bal_amt_in_lc) as irnGrpYtd, SUM(dly_ldgr_bal_amt_in_lc) as irnGrpDly,cob_dt"
        		+ "from customer360.c360_depst_dtls_fact where cob_dt >= ? and cob_dt <= ? and type <> '2109'  and acn = ? and cast(irn as double) between ? and ? and grp in (?) group by acn,cob_dt";
           
        String sql_final = (this.SQL_TEMPLATE+ sql_filling);
        PreparedStatement statement = null;
        try {
            System.out.println(" acn_irn_only sc");
            statement = c.prepareStatement(sql_final);
            int parameterIndex = 1;
            statement.setString(parameterIndex ++, request.getFromDate());
            statement.setString(parameterIndex ++, request.getToDate());
            statement.setString(parameterIndex ++, request.getCif());
            statement.setString(parameterIndex ++, request.getIrn_str());
            statement.setString(parameterIndex ++, request.getIrn_end());
            if(request.getGrp().equals("CASA")) {
            	String getGrp = request.getGrp();
            	getGrp = "DDA','SAV";
            statement.setString(parameterIndex ++,getGrp);
            } 
            if(request.getGrp().equals("FD")) {
            	String getGrp = request.getGrp();
            	getGrp = "CD";
            statement.setString(parameterIndex ++, getGrp);
            }
            System.out.println(statement.toString());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return statement;
    }  
  
    public PreparedStatement acn_crcd_grp_only(Connection c){
        String sql_filling = " crcd,cob_dt from customer360.c360_depst_dtls_fact where cob_dt >= ? and cob_dt <= ? and type <> '2109'  and acn = ? and crcd in (%s) and grp in (?) group by acn,crcd,cob_dt";
        PreparedStatement statement = null;

        try {
            StringBuilder placeholdersBuilder = new StringBuilder();
            for (int i = 0; i < request.getCrcd().size(); i++) {
                placeholdersBuilder.append("?");
                if (i < request.getCrcd().size() - 1) {
                    placeholdersBuilder.append(",");
                }
            }
            String placeholders = placeholdersBuilder.toString();
            String sql_final = String.format(this.SQL_TEMPLATE +sql_filling,placeholders);

            System.out.println("acn_crcd_only sc");
            statement = c.prepareStatement(sql_final);
            int parameterIndex = 1;
            statement.setString(parameterIndex ++, request.getFromDate());
            statement.setString(parameterIndex ++, request.getToDate());
            statement.setString(parameterIndex ++, request.getCif());  

            for (int i = 0; i < request.getCrcd().size(); i++) {
                statement.setString(parameterIndex++, request.getCrcd().get(i));
            }
            if(request.getGrp().equals("CASA")) {
            	String getGrp = request.getGrp();
            	getGrp = "DDA','SAV";
            statement.setString(parameterIndex ++,getGrp);
            } 
            if(request.getGrp().equals("FD")) {
            	String getGrp = request.getGrp();
            	getGrp = "CD";
            statement.setString(parameterIndex ++, getGrp);
            }
            System.out.println(statement.toString());

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return statement;
    }  
    
    
    public PreparedStatement acn_irn_crcd_grp_only(Connection c){
        String sql_filling = "SUM(ytd_ldgr_bal_amt_in_lc) as irnGrpYtd, SUM(dly_ldgr_bal_amt_in_lc) as irnGrpDly, cob_dt from customer360.c360_depst_dtls_fact where cob_dt >= ? and cob_dt <= ? and type <> '2109'  and acn = ? and boo = ? and crcd in (%s) and irn <= ? and irn >= ? and grp in (?) group by acn,crcd,boo,cob_dt ";
           
        PreparedStatement statement = null;
        try {
        	
            StringBuilder placeholdersBuilder = new StringBuilder();
            for (int i = 0; i < request.getCrcd().size(); i++) {
                placeholdersBuilder.append("?");
                if (i < request.getCrcd().size() - 1) {
                    placeholdersBuilder.append(",");
                }
            }
            String placeholders = placeholdersBuilder.toString();
            String sql_final = String.format(this.SQL_TEMPLATE +sql_filling,placeholders);
            
            System.out.println("acn_irn_crcd_only sc");
            statement = c.prepareStatement(sql_final);
            int parameterIndex = 1;
            statement.setString(parameterIndex ++, request.getFromDate());
            statement.setString(parameterIndex ++, request.getToDate());
            statement.setString(parameterIndex ++, request.getCif());
            statement.setString(parameterIndex ++, request.getBranch());
            
            for (int i = 0; i < request.getCrcd().size(); i++) {
                statement.setString(parameterIndex++, request.getCrcd().get(i));
            }
            
            statement.setString(parameterIndex ++, request.getIrn_str());
            statement.setString(parameterIndex ++, request.getIrn_end());
            if(request.getGrp().equals("CASA")) {
            	String getGrp = request.getGrp();
            	getGrp = "DDA','SAV";
            statement.setString(parameterIndex ++,getGrp);
            } 
            if(request.getGrp().equals("FD")) {
            	String getGrp = request.getGrp();
            	getGrp = "CD";
            statement.setString(parameterIndex ++, getGrp);
            }
            System.out.println(statement.toString());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return statement;
    }       
    public PreparedStatement acn_branch_grp_only(Connection c){
        String sql_filling = "cob_dt,boo as branch from customer360.c360_depst_dtls_fact where cob_dt >= ? and cob_dt <= ? and type <> '2109'  and acn = ? and boo = ? and grp in (?) group by acn,boo,cob_dt ";
           
        String sql_final = (this.SQL_TEMPLATE+ sql_filling);
        PreparedStatement statement = null;
        try {
            System.out.println("sc");
            statement = c.prepareStatement(sql_final);
            int parameterIndex = 1;
            statement.setString(parameterIndex ++, request.getFromDate());
            statement.setString(parameterIndex ++, request.getToDate());
            statement.setString(parameterIndex ++, request.getCif());
            statement.setString(parameterIndex ++, request.getBranch());
            if(request.getGrp().equals("CASA")) {
            	String getGrp = request.getGrp();
            	getGrp = "DDA','SAV";
            statement.setString(parameterIndex ++,getGrp);
            } 
            if(request.getGrp().equals("FD")) {
            	String getGrp = request.getGrp();
            	getGrp = "CD";
            statement.setString(parameterIndex ++, getGrp);
            }
            System.out.println(statement.toString());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return statement;
    }
    
    public PreparedStatement acn_branch_irn_grp_only(Connection c){
        String sql_filling = "SUM(ytd_ldgr_bal_amt_in_lc) as irnGrpYtd, SUM(dly_ldgr_bal_amt_in_lc) as irnGrpDly,boo as branch,cob_dt from customer360.c360_depst_dtls_fact where cob_dt >= ? and cob_dt <= ? and type <> '2109'  and acn = ? and substring(boo,1,3) = ? and irn <= ? and  irn >= ? and grp in (?) group by acn,boo,cob_dt ";
           
        String sql_final = (this.SQL_TEMPLATE+ sql_filling);
        PreparedStatement statement = null;
        try {
            System.out.println("sc");
            statement = c.prepareStatement(sql_final);
            int parameterIndex = 1;
            statement.setString(parameterIndex ++, request.getFromDate());
            statement.setString(parameterIndex ++, request.getToDate());
            statement.setString(parameterIndex ++, request.getCif());
            statement.setString(parameterIndex ++, request.getBranch());
            statement.setString(parameterIndex ++, request.getIrn_str());
            statement.setString(parameterIndex ++, request.getIrn_end());
            if(request.getGrp().equals("CASA")) {
            	String getGrp = request.getGrp();
            	getGrp = "DDA','SAV";
            statement.setString(parameterIndex ++,getGrp);
            } 
            if(request.getGrp().equals("FD")) {
            	String getGrp = request.getGrp();
            	getGrp = "CD";
            statement.setString(parameterIndex ++, getGrp);
            }
            System.out.println(statement.toString());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return statement;
    }
    public PreparedStatement acn_branch_crcd_grp_only(Connection c){
        String sql_filling = "crcd,boo as branch,cob_dt from customer360.c360_depst_dtls_fact where cob_dt >= ? and cob_dt <= ? and type <> '2109'  and acn = ? and substring(boo,1,3) = ? and crcd in (%s) and grp in (?) group by acn,crcd,boo,cob_dt ";
        String sql_filling_2 = "crcd,boo as branch,cob_dt from customer360.c360_depst_dtls_fact where cob_dt >= ? and cob_dt <= ? and type <> '2109'  and acn = ? and substring(boo,1,3) = ? and crcd in (%s) and grp in (?) group by acn,crcd,boo,cob_dt ";
   
        PreparedStatement statement = null;
        try {
        	
            StringBuilder placeholdersBuilder = new StringBuilder();
            for (int i = 0; i < request.getCrcd().size(); i++) {
                placeholdersBuilder.append("?");
                if (i < request.getCrcd().size() - 1) {
                    placeholdersBuilder.append(",");
                }
            }
            
            String placeholders = placeholdersBuilder.toString();
            String sql_final = String.format(this.SQL_TEMPLATE +sql_filling,placeholders);
            System.out.println("sc");
            statement = c.prepareStatement(sql_final);
            int parameterIndex = 1;
            statement.setString(parameterIndex ++, request.getFromDate());
            statement.setString(parameterIndex ++, request.getToDate());
            statement.setString(parameterIndex ++, request.getCif());
            statement.setString(parameterIndex ++, request.getBranch());
            
            for (int i = 0; i < request.getCrcd().size(); i++) {
                statement.setString(parameterIndex++, request.getCrcd().get(i));
            }
            
            if(request.getGrp().equals("CASA")) {
            	String getGrp = request.getGrp();
            	getGrp = "DDA','SAV";
            statement.setString(parameterIndex ++,getGrp);
            } 
            if(request.getGrp().equals("FD")) {
            	String getGrp = request.getGrp();
            	getGrp = "CD";
            statement.setString(parameterIndex ++, getGrp);
            }
            System.out.println(statement.toString());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return statement;
    }
    public PreparedStatement acn_branch_irn_crcd_grp_only(Connection c){
        String sql_filling = "SUM(YTD_AVG_LDGR_BAL_AMT_IN_LC) as irnGrpYtd,,crcd,boo as branch,crcd,ccob_dt from customer360.c360_depst_dtls_fact where cob_dt >= ? and cob_dt <= ? and type <> '2109' and acn = ? and substring(boo,1,3) = ? and crcd in (%s) and irn <= ? and irn >= ? group by acn,crcd,boo,cob_dt ";
         
        PreparedStatement statement = null;
        try {
        	
            StringBuilder placeholdersBuilder = new StringBuilder();
            for (int i = 0; i < request.getCrcd().size(); i++) {
                placeholdersBuilder.append("?");
                if (i < request.getCrcd().size() - 1) {
                    placeholdersBuilder.append(",");
                }
            }
            String placeholders = placeholdersBuilder.toString();
            String sql_final = String.format(this.SQL_TEMPLATE +sql_filling,placeholders);
            System.out.println("sc");
            statement = c.prepareStatement(sql_final);
            int parameterIndex = 1;
            statement.setString(parameterIndex ++, request.getFromDate());
            statement.setString(parameterIndex ++, request.getToDate());
            statement.setString(parameterIndex ++, request.getCif());
            statement.setString(parameterIndex ++, request.getBranch());
            
            for (int i = 0; i < request.getCrcd().size(); i++) {
                statement.setString(parameterIndex++, request.getCrcd().get(i));
            }
            
            statement.setString(parameterIndex ++, request.getIrn_str());
            statement.setString(parameterIndex ++, request.getIrn_end());
            if(request.getGrp().equals("CASA")) {
            	String getGrp = request.getGrp();
            	getGrp = "DDA','SAV";
            statement.setString(parameterIndex ++,getGrp);
            } 
            if(request.getGrp().equals("FD")) {
            	String getGrp = request.getGrp();
            	getGrp = "CD";
            statement.setString(parameterIndex ++, getGrp);
            }
            System.out.println(statement.toString());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return statement;
    }
    
public PreparedStatement SQLPrepareFinal(Connection c) {
    if (this.request.getBranch() == null) {
        if (this.request.getCrcd() == null || request.getCrcd().isEmpty()) {
            if (this.request.getIrn_end() == null && this.request.getIrn_str() == null) {
            	if(this.request.getGrp() == null) {
                System.out.println("acn_only final success");
                return acn_only(c);
            	}else if (this.request.getGrp() != null) {
            		return acn_only_grp(c);	
            	}
            } else if (this.request.getIrn_end() != null && this.request.getIrn_str() != null) {
            	if (this.request.getGrp() != null)  {
            		return acn_irn_grp_only(c);
            	}else 
                System.out.println("acn_irn_only final success");
                return acn_irn_only(c);
            }
        } else if (this.request.getCrcd() != null || !request.getCrcd().isEmpty() ) {
            if (this.request.getIrn_end() == null && this.request.getIrn_str() == null) {
            	if (this.request.getGrp() != null)  {
            		return acn_crcd_grp_only(c);
            	}else 
                System.out.println("acn_crcd_only final success");
                return acn_crcd_only(c);
            } else if (this.request.getIrn_end() != null && this.request.getIrn_str() != null) {
            	if (this.request.getGrp() != null)  {
            		return acn_irn_crcd_grp_only(c);
            	}else 
                System.out.println("acn_irn_crcd_only final success");
                return acn_irn_crcd_only(c);
            }
        }
    } else { // Branch is not null
        if (this.request.getCrcd() == null || request.getCrcd().isEmpty()) {
            if (this.request.getIrn_end() == null && this.request.getIrn_str() == null) {
            	if (this.request.getGrp() != null)  {
            		return acn_branch_grp_only(c);
            	}else 
                System.out.println("acn_branch_crcd_only final success");
                return acn_branch_only(c);
            } else if (this.request.getIrn_end() != null && this.request.getIrn_str() != null) {
            	if (this.request.getGrp() != null)  {
            		return acn_branch_irn_grp_only(c);
            	}else 
            	 System.out.println("acn_branch_irn_crcd_only final success");
                return acn_branch_irn_only(c);
            }
        } else if (this.request.getCrcd() != null || !request.getCrcd().isEmpty()) {
            if (this.request.getIrn_end() == null && this.request.getIrn_str() == null) {
            	if (this.request.getGrp() != null)  {
            		return acn_branch_crcd_grp_only(c);
            	}else 
                System.out.println("acn_crcd_branch_only final success");
                return acn_branch_crcd_only(c);
            }  if (this.request.getIrn_end() == null && this.request.getIrn_str() == null) {
            	if (this.request.getGrp() != null)  {
            		return acn_branch_irn_crcd_grp_only(c);
            	}
            	}else {
            	System.out.println("acn_irn_crcd_branch_only final success");
                return acn_branch_irn_crcd_only(c);
            }
        }
    }
    // Default case to handle paths where no condition is met
    throw new IllegalStateException("No matching conditions for SQLPrepareFinal.");
}
}

