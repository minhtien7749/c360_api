package service;

import dao.request.CustomerComplaintsRequest;
import dao.request.DepDltFactRequest;
import dao.request.MoneyTransactionRequest;
import dao.request.TaxDataRequest;
import dao.response.Response;
import dao.response.ResponseDto;
import database.JdbcUtils;
import c360.model.CustomerComplaints;
import c360.model.DepDtlFact;
import c360.model.DepDtlFactDto;
import c360.model.TaxData;
import c360.model.MoneyTransaction;
import query.CustomerComplaintsQuery;
import query.DepDltFactQuery;
import query.TaxDataQuery;
import query.MoneyTransactionQuery;

import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class CorpStatementService {


public static Response getMoneyTransaction(MoneyTransactionRequest request){
    JdbcUtils jdbcUtils = new JdbcUtils();
    MoneyTransactionQuery query = new MoneyTransactionQuery(request);
    ArrayList<MoneyTransaction> moneyTransactions = new ArrayList();
    Connection c = null;
    try {
        c = jdbcUtils.getConnectionUat();
        PreparedStatement statement = query.returnSql(c);
        ResultSet rc = statement.executeQuery();
        System.out.println(statement.toString());
        while (rc.next()){
        	String acn =rc.getString("acn");
        	String ofscid =rc.getString("ofscid");
        	String ofsname =rc.getString("ofsname");
        	String bank_code =rc.getString("bank_code");
        	String short_name =rc.getString("short_name");
        	String trx_type =rc.getString("trx_type");
        	String ofsbrn =rc.getString("ofsbrn");
        	String trans_type_flag =rc.getString("trans_type_flag");
        	String mtd_total_amount_transaction_lc =rc.getString("mtd_total_amount_transaction_lc");
        	String count_mtd_transaction =rc.getString("count_mtd_transaction");
        	String cob_dt =rc.getString("cob_dt");
        	moneyTransactions.add(new MoneyTransaction(acn,ofscid,ofsname,bank_code,short_name,trx_type,ofsbrn,trans_type_flag,mtd_total_amount_transaction_lc,count_mtd_transaction,cob_dt));
        }
    }
    catch (SQLException e){
        System.out.println(e.getCause());
        System.out.println(e.getMessage());
        return new Response(request.getRequestId(), true, e.getMessage(), e.getErrorCode(), new ArrayList<>());
    }
    return new Response(request.getRequestId(), false,"Success",null, moneyTransactions);
}

public static Response getDepDtlFact(DepDltFactRequest request) throws NoSuchAlgorithmException, KeyManagementException {
    JdbcUtils jdbcUtils = new JdbcUtils();
    DepDltFactQuery query = new DepDltFactQuery(request);
    ArrayList<DepDtlFact> depDtlFact = new ArrayList<>();
    Connection c = null;

    try {
        c = jdbcUtils.getConnectionUat();
        PreparedStatement statement = query.SQLPrepareFinal(c);
        ResultSet rc = statement.executeQuery();
        System.out.println(statement.toString());

        while (rc.next()) {
            String cif = rc.getString("acn");
            String ytdAvgBalAmt = rc.getString("ytdAvgBalAmt");
            String ytdAvgBalAmtTc = rc.getString("ytdAvgBalAmtTc");
            String ytdOnlAvgBalAmt = rc.getString("ytdOnlAvgBalAmt");
            String ytdOnlAvgBalAmtTc = rc.getString("ytdOnlAvgBalAmtTc");
            String dlyBalAmt = rc.getString("dlyBalAmt");
            String dlyBalAmtTc = rc.getString("dlyBalAmtTc");
            String dlyOnBalAmt = rc.getString("dlyOnBalAmt");
            String dlyOnBalAmtTc = rc.getString("dlyOnBalAmtTc");
            String qtdAvgBalAmt = rc.getString("qtdAvgBalAmt");
            String qtdAvgBalAmtTc = rc.getString("qtdAvgBalAmtTc");
            String qtdOnlAvgBalAmt = rc.getString("qtdOnlAvgBalAmt");
            String qtdOnlAvgBalAmtTc = rc.getString("qtdOnlAvgBalAmtTc");
            String ytdNiiAmt = rc.getString("ytdNiiAmt");
            String ytdNimAmt = rc.getString("ytdNimAmt");
            String cob_dt = rc.getString("cob_dt");

            // Branch-specific logic
            String branch = (request.getBranch() != null) ? rc.getString("branch") : null;
            
            System.out.println("Pass condition branch");
            // Conditional logic to add DepDtlFact based on request parameters
            if(request.getGrp() != null ||  request.getGrp() == null) {
            	System.out.println(request.getGrp());
            if (request.getBranch() == null) {
                if (request.getCrcd() == null) {
                    System.out.println("It got here");
                        depDtlFact.add(new DepDtlFact(cif, null,null,ytdAvgBalAmt,ytdAvgBalAmtTc, ytdOnlAvgBalAmt,ytdOnlAvgBalAmtTc, ytdNiiAmt, dlyBalAmt,dlyBalAmtTc,dlyOnBalAmt,dlyOnBalAmtTc, qtdAvgBalAmt,qtdAvgBalAmtTc,qtdOnlAvgBalAmt,qtdOnlAvgBalAmtTc,ytdNimAmt, cob_dt));
//                    } else if (request.getIrn_end() != null && request.getIrn_str() != null) {
//                        String irnGrpDly = rc.getString("irnGrpDly");
//                        String irnGrpYtd = rc.getString("irnGrpYtd");
//                        depDtlFact.add(new DepDtlFact(cif,null,null,ytdAvgBalAmt,ytdAvgBalAmtTc, ytdOnlAvgBalAmt,ytdOnlAvgBalAmtTc, ytdNiiAmt,dlyBalAmt,dlyBalAmtTc, ytdNimAmt, cob_dt));
//                    } 
                        
                        
                        
                } else if (request.getCrcd() != null) {
                    String crcd = rc.getString("crcd");
                    System.out.println("It got here crcd");
                    depDtlFact.add(new DepDtlFact(cif,null, crcd, ytdAvgBalAmt,ytdAvgBalAmtTc, ytdOnlAvgBalAmt,ytdOnlAvgBalAmtTc, ytdNiiAmt, dlyBalAmt,dlyBalAmtTc,dlyOnBalAmt,dlyOnBalAmtTc, qtdAvgBalAmt,qtdAvgBalAmtTc,qtdOnlAvgBalAmt,qtdOnlAvgBalAmtTc, ytdNimAmt, cob_dt));
                }
                
   
            } else { 
                // Branch is not null
                if (request.getCrcd() == null) {
                    if (request.getIrn_end() == null && request.getIrn_str() == null) {
                    	 System.out.println("It got here branch");
                        depDtlFact.add(new DepDtlFact(cif, branch,null, ytdAvgBalAmt,ytdAvgBalAmtTc, ytdOnlAvgBalAmt,ytdOnlAvgBalAmtTc, ytdNiiAmt, dlyBalAmt,dlyBalAmtTc,dlyOnBalAmt,dlyOnBalAmtTc, qtdAvgBalAmt,qtdAvgBalAmtTc,qtdOnlAvgBalAmt,qtdOnlAvgBalAmtTc, ytdNimAmt, cob_dt));
                    } else if (request.getIrn_end() != null && request.getIrn_str() != null) {
//                        String irnGrpDly = rc.getString("irnGrpDly");
//                        String irnGrpYtd = rc.getString("irnGrpYtd");
                        depDtlFact.add(new DepDtlFact(cif, branch,null, ytdAvgBalAmt,ytdAvgBalAmtTc, ytdOnlAvgBalAmt,ytdOnlAvgBalAmtTc, ytdNiiAmt, dlyBalAmt,dlyBalAmtTc,dlyOnBalAmt,dlyOnBalAmtTc, qtdAvgBalAmt,qtdAvgBalAmtTc,qtdOnlAvgBalAmt,qtdOnlAvgBalAmtTc, ytdNimAmt, cob_dt));
                    }
                } else {
                    String crcd = rc.getString("crcd");
                    System.out.println("It got here branch crcd");
                    depDtlFact.add(new DepDtlFact(cif, branch, crcd, ytdAvgBalAmt,ytdAvgBalAmtTc, ytdOnlAvgBalAmt,ytdOnlAvgBalAmtTc, ytdNiiAmt, dlyBalAmt,dlyBalAmtTc,dlyOnBalAmt,dlyOnBalAmtTc, qtdAvgBalAmt,qtdAvgBalAmtTc,qtdOnlAvgBalAmt,qtdOnlAvgBalAmtTc, ytdNimAmt, cob_dt));
                }
            }
        }
        }
        System.out.println(depDtlFact.size());
        c.close();
    } catch (SQLException e) {
        System.out.println(e.getCause());
        System.out.println(e.getMessage());
        return new Response(request.getRequestId(), true, e.getMessage(), e.getErrorCode(), new ArrayList<>());
    }
    
    System.out.println(depDtlFact.toString().length());

//    Double dlyBalAmtTotalNum = (double) 0;
//    for (DepDtlFact obj: depDtlFact) {
//    	dlyBalAmtTotalNum += Double.parseDouble(obj.getDlyBalAmt());
//    }
//    System.out.println("dlyBalAmtTotalNum: " + dlyBalAmtTotalNum);
//
//    String ytdAvgBalAmtTotal = "0";
//    String ytdAvgBalAmtTcTotal = "0";
//    String ytdOnlAvgBalAmtTotal = "0";
//    String ytdOnlAvgBalAmtTcTotal = "0";
//    String dlyBalAmtTotal = dlyBalAmtTotalNum.toString();
//    String dlyBalAmtTcTotal = "0";
//    String ytdNiiAmtTotal = "0";
//    String ytdNimAmtTotal = "0";
//    String cob_dt = "0";
//    
//    DepDtlFactDto depDtlFactTotal= new DepDtlFactDto(
//    		ytdAvgBalAmtTotal,
//    		ytdAvgBalAmtTcTotal,
//    		ytdOnlAvgBalAmtTotal,
//    		ytdOnlAvgBalAmtTcTotal,
//    		dlyBalAmtTotal,
//    		dlyBalAmtTcTotal,
//    		ytdNiiAmtTotal,
//    		ytdNimAmtTotal,
//    		cob_dt,
//    		depDtlFact
//    );
//    System.out.println("depDtlFactTotal.getDlyBalAmtTotal(): " + depDtlFactTotal.getDlyBalAmtTotal());
   
    return new Response(request.getRequestId(), false, "Success", null, depDtlFact);
}



public static Response getTaxData(TaxDataRequest request) throws NoSuchAlgorithmException, KeyManagementException {
    JdbcUtils jdbcUtils = new JdbcUtils();
    TaxDataQuery query = new TaxDataQuery(request);
    ArrayList<TaxData> taxDatas = new ArrayList<>();
    Connection c = null;

    try {
        c = jdbcUtils.getConnection();
        PreparedStatement statement = query.returnSql(c);
        ResultSet rc = statement.executeQuery();
        System.out.println(statement.toString());

        while (rc.next()) {
        	String cob_dt = rc.getString("cob_dt");
        	String id = rc.getString("id");
        	String mst = rc.getString("tax_no");
        	String nguoiNopThue = rc.getString("name");
        	String cucThue = rc.getString("tax_city_dep");
        	String chiCucThue = rc.getString("tax_district_dept");
        	String soThongBaoCongKhai = rc.getString("rpt_num");
        	String rptDt = rc.getString("rpt_dt");
        	String bienPhapCuongCheDangApDung = rc.getString("apply");
        	String soTienNoThueVnd = rc.getString("tax_amt");
        	String link= rc.getString("link");
        	String status = rc.getString("status");
            taxDatas.add(new TaxData(cob_dt,id,mst,nguoiNopThue,cucThue,chiCucThue,soThongBaoCongKhai,rptDt,bienPhapCuongCheDangApDung,soTienNoThueVnd,link,status));
        }

        c.close();
    } catch (SQLException e) {
        System.out.println(e.getCause());
        System.out.println(e.getMessage());
        return new Response(request.getRequestId(), true, e.getMessage(), e.getErrorCode(), new ArrayList<>());
    }

    return new Response(request.getRequestId(), false, "Success", null, taxDatas);
}

public static Response getTaxDataUat(TaxDataRequest request) throws NoSuchAlgorithmException, KeyManagementException {
    JdbcUtils jdbcUtils = new JdbcUtils();
    TaxDataQuery query = new TaxDataQuery(request);
    System.out.println("get query sc");

    ArrayList<TaxData> taxDatas = new ArrayList<>();
    System.out.println("get array sc");
    Connection c = null;

    try {
        c = jdbcUtils.getConnectionUat();
        PreparedStatement statement = query.returnSql(c);
        ResultSet rc = statement.executeQuery();
        System.out.println(statement.toString());
        System.out.println("get Connection sc");
        while (rc.next()) {
        	String cob_dt = rc.getString("cob_dt");
        	String id = rc.getString("id");
        	String mst = rc.getString("tax_no");
        	String nguoiNopThue = rc.getString("name");
        	String cucThue = rc.getString("tax_city_dep");
        	String chiCucThue = rc.getString("tax_district_dept");
        	String soThongBaoCongKhai = rc.getString("rpt_num");
        	String rptDt = rc.getString("rpt_dt");
        	String bienPhapCuongCheDangApDung = rc.getString("apply");
        	String soTienNoThueVnd = rc.getString("tax_amt");
        	String link= rc.getString("link");
        	String status = rc.getString("status");
            taxDatas.add(new TaxData(cob_dt,id,mst,nguoiNopThue,cucThue,chiCucThue,soThongBaoCongKhai,rptDt,bienPhapCuongCheDangApDung,soTienNoThueVnd,link,status));
        }

        c.close();
    } catch (SQLException e) {
        System.out.println(e.getCause());
        System.out.println(e.getMessage());
        return new Response(request.getRequestId(), true, e.getMessage(), e.getErrorCode(), new ArrayList<>());
    }

    return new Response(request.getRequestId(), false, "Success", null, taxDatas);
}

public static Response getCustomerComplaints(CustomerComplaintsRequest request) throws NoSuchAlgorithmException, KeyManagementException {
    JdbcUtils jdbcUtils = new JdbcUtils();
    CustomerComplaintsQuery query = new CustomerComplaintsQuery(request);
    ArrayList<CustomerComplaints> CustomerComplaints = new ArrayList<>();
    Connection c = null;

    try {
    	c = jdbcUtils.getConnection();
        PreparedStatement statement = query.returnSql(c);
        ResultSet rc = statement.executeQuery();
        System.out.println(statement.toString());

        while (rc.next()) {
        	String stt = rc.getString("stt");
        	String thoi_gian_lien_he = rc.getString("thoi_gian_lien_he");
        	String ten_kh = rc.getString("ten_kh");
        	String tu_so = rc.getString("tu_so");
        	String cif = rc.getString("cif");
        	String yc_khieu_nai = rc.getString("yc_khieu_nai");
        	String ma_loi = rc.getString("ma_loi");
        	String contact = rc.getString("contact");
        	String atm_id = rc.getString("atm_id");
        	String so_luot_kh_phan_anh = rc.getString("so_luot_kh_phan_anh");
        	String nghiep_vu = rc.getString("nghiep_vu");
        	String nghiep_vu_chi_tiet = rc.getString("nghiep_vu_chi_tiet");
        	String kenh_gd = rc.getString("kenh_gd");
        	String doi_tuong = rc.getString("doi_tuong");
        	String phan_loai_don_vi_giai_quyet = rc.getString("phan_loai_don_vi_giai_quyet");
        	String don_vi_giai_quyet_cn = rc.getString("don_vi_giai_quyet_cn");
        	String don_vi_giai_quyet_cap_2_pgd = rc.getString("don_vi_giai_quyet_cap_2_pgd");
        	String nguyen_nhan = rc.getString("nguyen_nhan");
        	String ket_qua = rc.getString("ket_qua");
        	String phan_loai_nguyen_nhan = rc.getString("phan_loai_nguyen_nhan");
        	String note = rc.getString("note");
        	String ngay_bat_dau = rc.getString("ngay_bat_dau");
        	String ngay_ket_thuc = rc.getString("ngay_ket_thuc");
        	String phan_loai_kh = rc.getString("phan_loai_kh");
        	String cob_dt = rc.getString("cob_dt");
            CustomerComplaints.add(new CustomerComplaints(stt,thoi_gian_lien_he,ten_kh,tu_so,cif,yc_khieu_nai,ma_loi,contact,atm_id,so_luot_kh_phan_anh,nghiep_vu,nghiep_vu_chi_tiet,kenh_gd,doi_tuong,phan_loai_don_vi_giai_quyet,don_vi_giai_quyet_cn,don_vi_giai_quyet_cap_2_pgd,nguyen_nhan,ket_qua,phan_loai_nguyen_nhan,note,ngay_bat_dau,ngay_ket_thuc,phan_loai_kh,cob_dt));
        }

        c.close();
    } catch (SQLException e) {
        System.out.println(e.getCause());
        System.out.println(e.getMessage());
        return new Response(request.getRequestId(), true, e.getMessage(), e.getErrorCode(), new ArrayList<>());
    }

    return new Response(request.getRequestId(), false, "Success", null, CustomerComplaints);
}

public static Response getCustomerComplaintsUat(CustomerComplaintsRequest request) throws NoSuchAlgorithmException, KeyManagementException {
    JdbcUtils jdbcUtils = new JdbcUtils();
    CustomerComplaintsQuery query = new CustomerComplaintsQuery(request);
    ArrayList<CustomerComplaints> CustomerComplaints = new ArrayList<>();
    Connection c = null;

    try {
    	c = jdbcUtils.getConnectionUat();
        PreparedStatement statement = query.returnSql(c);
        ResultSet rc = statement.executeQuery();
        System.out.println(statement.toString());
        while (rc.next()) {
        	String stt = rc.getString("stt");
        	String thoiGianLienHe = rc.getString("thoi_gian_lien_he");
        	String tenKh = rc.getString("ten_kh");
        	String tuSo = rc.getString("tu_so");
        	String cif = rc.getString("cif");
        	String ycKhieuNai = rc.getString("yc_khieu_nai");
        	String maLoi = rc.getString("ma_loi");
        	String contact = rc.getString("contact");
        	String atmId = rc.getString("atm_id");
        	String soLuotKhPhanAnh = rc.getString("so_luot_kh_phan_anh");
        	String nghiepVu = rc.getString("nghiep_vu");
        	String nghiepVuChiTiet = rc.getString("nghiep_vu_chi_tiet");
        	String kenhGd = rc.getString("kenh_gd");
        	String doiTuong = rc.getString("doi_tuong");
        	String phanLoaiDonViGiaiQuyet = rc.getString("phan_loai_don_vi_giai_quyet");
        	String donViQiaiQuyetCn = rc.getString("don_vi_giai_quyet_cn");
        	String donViGiaiQuyetCap2Pgd = rc.getString("don_vi_giai_quyet_cap_2_pgd");
        	String nguyenNhan = rc.getString("nguyen_nhan");
        	String ketQua = rc.getString("ket_qua");
        	String phanLoaiNguyenNhan = rc.getString("phan_loai_nguyen_nhan");
        	String note = rc.getString("note");
        	String ngayBatDau = rc.getString("ngay_bat_dau");
        	String ngayKetThuc = rc.getString("ngay_ket_thuc");
        	String phanLoaiKh = rc.getString("phan_loai_kh");
        	String cobDt = rc.getString("cob_dt");
        	
        	
            CustomerComplaints.add(new CustomerComplaints(stt,thoiGianLienHe,tenKh,tuSo,cif,ycKhieuNai,maLoi,contact,atmId,soLuotKhPhanAnh,nghiepVu,nghiepVuChiTiet,kenhGd,doiTuong,phanLoaiDonViGiaiQuyet,donViQiaiQuyetCn,donViGiaiQuyetCap2Pgd,nguyenNhan,ketQua,phanLoaiNguyenNhan,note,ngayBatDau,ngayKetThuc,phanLoaiKh,cobDt));
        }

        c.close();
    }catch (SQLException e) {
  
        System.out.println(e.getCause());
        System.out.println(e.getMessage());
        return new Response(request.getRequestId(), true, e.getMessage(), e.getErrorCode(), new ArrayList<>());
    }

    return new Response(request.getRequestId(), false, "Success", null, CustomerComplaints);
}
}
