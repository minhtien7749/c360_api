package dao.request;

public class CorpStatementRequest {
    private String requestId;
    private String cif;
    private String account;
    private String fromDate;
    private String toDate;

    public CorpStatementRequest(String requestId, String cif, String account, String fromDate, String toDate) {
        this.requestId = requestId;
        this.cif = cif;
        this.account = account;
        this.fromDate = fromDate;
        this.toDate = toDate;
    }

    public String getRequestId() {
        return requestId;
    }

    public String getCif() {
        return cif;
    }

    public String getAccount() {
        return account;
    }

    public String getFromDate() {
        return fromDate;
    }

    public String getToDate() {
        return toDate;
    }
}
