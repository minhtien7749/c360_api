package dao.request;

public class CustomerComplaintsRequest {

}
