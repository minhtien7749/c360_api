package dao.request;

public class DepDltFactRequest {
	 private String requestId;
	    private String cif;
	    private String branch;
	    private String irn_str;
	    private String irn_end;
	    private String crcd;
	    private String fromDate;
	    private String toDate;
	        
		public DepDltFactRequest(String requestId, String cif, String branch, String irn_str, String irn_end,
			String crcd, String fromDate, String toDate) {
			this.requestId = requestId;
			this.cif = cif;
			this.branch = branch;
			this.irn_str = irn_str;
			this.irn_end = irn_end;
			this.crcd = crcd;
			this.fromDate = fromDate;
			this.toDate = toDate;
		}
		
		
		public String getIrn_str() {
			return irn_str;
		}
		public void setIrn_str(String irn_str) {
			this.irn_str = irn_str;
		}
		public String getIrn_end() {
			return irn_end;
		}
		public void setIrn_end(String irn_end) {
			this.irn_end = irn_end;
		}
		public String getCrcd() {
			return crcd;
		}
		public void setCrcd(String crcd) {
			this.crcd = crcd;
		}
		public String getRequestId() {
			return requestId;
		}
		public void setRequestId(String requestId) {
			this.requestId = requestId;
		}
		public String getCif() {
			return cif;
		}
		public void setCif(String cif) {
			this.cif = cif;
		}
		public String getBranch() {
			return branch;
		}
		public void setBranch(String branch) {
			this.branch = branch;
		}

		public String getFromDate() {
			return fromDate;
		}
		public void setFromDate(String fromDate) {
			this.fromDate = fromDate;
		}
		public String getToDate() {
			return toDate;
		}
		public void setToDate(String toDate) {
			this.toDate = toDate;
		}
	    
	    
	    
}
