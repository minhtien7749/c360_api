package model;

public class DepDtlFact {
private String cif;
private String branch;
private String crcd;
private String ytdAvgBalAmt;
private String ytdOnlAvgBalAmt;
private String dlyBalAmt;
private String irnGrpDly;
private String irnGrpYtd;
private String ytdNiiAmt;
private String dlyBalAmtTotal;
private String ytdNimAmt;
private String cob_dt;

// có mã tiền lẫn lãi,
public DepDtlFact(String cif,String branch,String crcd, String ytdAvgBalAmt,
String ytdOnlAvgBalAmt,String ytdNiiAmt,String dlyBalAmtTotal,String ytdNimAmt,String irnGrpDly,String irnGrpYtd,String cob_dt) {
	this.cif = cif;
	this.crcd = crcd;
	this.branch = branch;
	this.ytdAvgBalAmt = ytdAvgBalAmt;
	this.ytdOnlAvgBalAmt = ytdOnlAvgBalAmt;
	this.ytdNiiAmt = ytdNiiAmt;
	this.dlyBalAmtTotal = dlyBalAmtTotal;
	this.irnGrpDly = irnGrpDly;
	this.irnGrpYtd= irnGrpYtd;
	this.ytdNimAmt= ytdNimAmt;
	this.cob_dt = cob_dt;
}

public String getCrcd() {
	return crcd;
}

public void setCrcd(String crcd) {
	this.crcd = crcd;
}

public String getCif() {
	return cif;
}

public void setCif(String cif) {
	this.cif = cif;
}

public String getBranch() {
	return branch;
}
public void setBranch(String branch) {
	this.branch = branch;
}
public String getYtdAvgBalAmt() {
	return ytdAvgBalAmt;
}
public void setYtdAvgBalAmt(String ytdAvgBalAmt) {
	this.ytdAvgBalAmt = ytdAvgBalAmt;
}

public String getYtdOnlAvgBalAmt() {
	return ytdOnlAvgBalAmt;
}

public void setYtdOnlAvgBalAmt(String ytdOnlAvgBalAmt) {
	this.ytdOnlAvgBalAmt = ytdOnlAvgBalAmt;
}

public String getIrnGrpYtd() {
	return irnGrpYtd;
}

public void setIrnGrpYtd(String irnGrpYtd) {
	this.irnGrpYtd = irnGrpYtd;
}

public String getDlyBalAmt() {
	return dlyBalAmt;
}

public void setDlyBalAmt(String dlyBalAmt) {
	this.dlyBalAmt = dlyBalAmt;
}

public String getIrnGrpDly() {
	return irnGrpDly;
}

public void setIrnGrpDly(String irnGrpDly) {
	this.irnGrpDly = irnGrpDly;
}

public String getYtdNiiAmt() {
	return ytdNiiAmt;
}

public void setYtdNiiAmt(String ytdNiiAmt) {
	this.ytdNiiAmt = ytdNiiAmt;
}

public String getDlyBalAmtTotal() {
	return dlyBalAmtTotal;
}

public void setDlyBalAmtTotal(String dlyBalAmtTotal) {
	this.dlyBalAmtTotal = dlyBalAmtTotal;
}

public String getYtdNimAmt() {
	return ytdNimAmt;
}

public void setYtdNimAmt(String ytdNimAmt) {
	this.ytdNimAmt = ytdNimAmt;
}

public String getCob_dt() {
	return cob_dt;
}

public void setCob_dt(String cob_dt) {
	this.cob_dt = cob_dt;
}


}
