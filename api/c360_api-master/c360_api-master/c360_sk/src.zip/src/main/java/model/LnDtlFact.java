package model;

public class LnDtlFact {
	private String accountNo;
	private String branch;
}
