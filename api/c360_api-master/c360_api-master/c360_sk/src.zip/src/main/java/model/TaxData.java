package model;

public class TaxData {

}
