package query;

import dao.request.CorpStatementRequest;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class CorpStatementQuery {
	private final  String SQL_TEMPLATE = "select *, count() over (partition by cif, account , itc1) as cred_or_deb, row_number() over ( order by cast(transactionnumber as decimal(20,6))) as beginning, \n" +
            "row_number() over ( order by cast(transactionnumber as decimal(20,6)) desc ) as ending, \n" +
            "sum(debit) over (partition by cif, account) as total_debit, \n" +
            "sum(credit) over (partition by cif, account) as total_credit, accountbal - credit + debit as begball from production.corp_statement_dtls where cob_dt >= ? and cob_dt <= ? and cif = ? and account = ?";
    private CorpStatementRequest request;

    public CorpStatementQuery(CorpStatementRequest request) {
        this.request = request;
    }
    public PreparedStatement returnSql(Connection connection) throws SQLException {
        PreparedStatement statement = connection.prepareStatement(SQL_TEMPLATE);
        System.out.println("sc");
        int parameterIndex = 1;
        statement.setString(parameterIndex ++, request.getFromDate());
        statement.setString(parameterIndex ++, request.getToDate());
        statement.setString(parameterIndex ++, request.getCif());
        statement.setString(parameterIndex ++, request.getAccount());
        System.out.println("sc");
        return statement;
    }
}