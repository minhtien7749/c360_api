package query;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import dao.request.DepDltFactRequest;

public class DepDltFactQuery {
	private final  String SQL_TEMPLATE = "select acn,"
			+ "SUM(ytd_ldgr_bal_amt_in_lc) as ytdAvgBalAmt, "
			+ "sum(case when zchanid in ('78','77') then ytd_ldgr_bal_amt_in_lc end) as ytdOnlAvgBalAmt,"
			+ "SUM(dly_ldgr_bal_amt_in_lc) as dlyBalAmt,\n"
			+ "SUM(ytd_nii_alco_amt_in_lc) / SUM(ytd_avg_ldgr_bal_amt_in_lc) as ytdNimAmt,\n"
			+ "SUM(ytd_nii_alco_amt_in_lc) as ytdNiiAmt,\n"
			+ "SUM(case when grp in ('DDA', 'SAV') then DLY_LDGR_BAL_AMT_IN_LC end) as dlyBalAmtTotal,  \n"
			+ "SUM(case when grp in ('DDA', 'SAV') then YTD_AVG_LDGR_BAL_AMT_IN_LC end) as ytdAvgBalAmt,\n";
	

    private DepDltFactRequest request;

    public DepDltFactQuery(DepDltFactRequest request) {
        this.request = request;
    }


    public PreparedStatement acn_only(Connection c){
        String sql_filling = " cob_dt from customer360.c360_depst_dtls_fact where cob_dt >= ? and cob_dt <= ? and acn = ? group by acn,cob_dt ";
        String sql_final = (this.SQL_TEMPLATE+ sql_filling);
        PreparedStatement statement = null;
        try {
            System.out.println("acn_only sc");
            statement = c.prepareStatement(sql_final);
            int parameterIndex = 1;
            statement.setString(parameterIndex ++, request.getFromDate());
            statement.setString(parameterIndex ++, request.getToDate());
            statement.setString(parameterIndex ++, request.getCif());
//            System.out.println(statement.toString());

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return statement;
    }
    
    public PreparedStatement acn_irn_only(Connection c){
        String sql_filling = "SUM(ytd_ldgr_bal_amt_in_lc) as irnGrpYtd, SUM(dly_ldgr_bal_amt_in_lc) as irnGrpDly,cob_dt"
        		+ "from customer360.c360_depst_dtls_fact where cob_dt >= ? and cob_dt <= ? and acn = ? and cast(irn as double) between ? and ? group by acn,cob_dt";
           
        String sql_final = (this.SQL_TEMPLATE+ sql_filling);
        PreparedStatement statement = null;
        try {
            System.out.println(" acn_irn_only sc");
            statement = c.prepareStatement(sql_final);
            int parameterIndex = 1;
            statement.setString(parameterIndex ++, request.getFromDate());
            statement.setString(parameterIndex ++, request.getToDate());
            statement.setString(parameterIndex ++, request.getCif());
            statement.setString(parameterIndex ++, request.getIrn_str());
            statement.setString(parameterIndex ++, request.getIrn_end());
            System.out.println(statement.toString());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return statement;
    }  
  
    public PreparedStatement acn_crcd_only(Connection c){
        String sql_filling = " cob_dt from customer360.c360_depst_dtls_fact where cob_dt >= ? and cob_dt <= ? and acn = ? and crcd = ? group by acn,crcd,cob_dt";
           
        String sql_final = (this.SQL_TEMPLATE+ sql_filling);
        PreparedStatement statement = null;
        try {
            System.out.println("acn_crcd_only sc");
            statement = c.prepareStatement(sql_final);
            int parameterIndex = 1;
            statement.setString(parameterIndex ++, request.getFromDate());
            statement.setString(parameterIndex ++, request.getToDate());
            statement.setString(parameterIndex ++, request.getCif());
            statement.setString(parameterIndex ++, request.getCrcd());
            System.out.println(statement.toString());

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return statement;
    }  
    
    
    public PreparedStatement acn_irn_crcd_only(Connection c){
        String sql_filling = "SUM(ytd_ldgr_bal_amt_in_lc) as irnGrpYtd, SUM(dly_ldgr_bal_amt_in_lc) as irnGrpDly, cob_dt from customer360.c360_depst_dtls_fact where cob_dt >= ? and cob_dt <= ? and acn = ? and boo = ? and crcd = ? and irn <= ? and irn >= ? group by acn,crcd,boo,cob_dt ";
           
        String sql_final = (this.SQL_TEMPLATE+ sql_filling);
        PreparedStatement statement = null;
        try {
            System.out.println("acn_irn_crcd_only sc");
            statement = c.prepareStatement(sql_final);
            int parameterIndex = 1;
            statement.setString(parameterIndex ++, request.getFromDate());
            statement.setString(parameterIndex ++, request.getToDate());
            statement.setString(parameterIndex ++, request.getCif());
            statement.setString(parameterIndex ++, request.getBranch());
            statement.setString(parameterIndex ++, request.getCrcd());
            statement.setString(parameterIndex ++, request.getIrn_str());
            statement.setString(parameterIndex ++, request.getIrn_end());
            System.out.println(statement.toString());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return statement;
    }       
    public PreparedStatement acn_branch_only(Connection c){
        String sql_filling = "cob_dt,boo as branch from customer360.c360_depst_dtls_fact where cob_dt >= ? and cob_dt <= ? and acn = ? and boo = ? group by acn,boo,cob_dt ";
           
        String sql_final = (this.SQL_TEMPLATE+ sql_filling);
        PreparedStatement statement = null;
        try {
            System.out.println("sc");
            statement = c.prepareStatement(sql_final);
            int parameterIndex = 1;
            statement.setString(parameterIndex ++, request.getFromDate());
            statement.setString(parameterIndex ++, request.getToDate());
            statement.setString(parameterIndex ++, request.getCif());
            statement.setString(parameterIndex ++, request.getBranch());
            System.out.println(statement.toString());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return statement;
    }
    
    public PreparedStatement acn_branch_irn_only(Connection c){
        String sql_filling = "SUM(ytd_ldgr_bal_amt_in_lc) as irnGrpYtd, SUM(dly_ldgr_bal_amt_in_lc) as irnGrpDly,boo as branch,cob_dt from customer360.c360_depst_dtls_fact where cob_dt >= ? and cob_dt <= ? and acn = ? and boo = ? and irn <= ? and  irn >= ? group by acn,boo,cob_dt ";
           
        String sql_final = (this.SQL_TEMPLATE+ sql_filling);
        PreparedStatement statement = null;
        try {
            System.out.println("sc");
            statement = c.prepareStatement(sql_final);
            int parameterIndex = 1;
            statement.setString(parameterIndex ++, request.getFromDate());
            statement.setString(parameterIndex ++, request.getToDate());
            statement.setString(parameterIndex ++, request.getCif());
            statement.setString(parameterIndex ++, request.getBranch());
            statement.setString(parameterIndex ++, request.getIrn_str());
            statement.setString(parameterIndex ++, request.getIrn_end());
            System.out.println(statement.toString());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return statement;
    }
    public PreparedStatement acn_branch_crcd_only(Connection c){
        String sql_filling = "crcd,boo as branch,cob_dt from customer360.c360_depst_dtls_fact where cob_dt >= ? and cob_dt <= ? and acn = ? and boo = ? and crcd = ? group by acn,crcd,boo,cob_dt ";
           
        String sql_final = (this.SQL_TEMPLATE+ sql_filling);
        PreparedStatement statement = null;
        try {
            System.out.println("sc");
            statement = c.prepareStatement(sql_final);
            int parameterIndex = 1;
            statement.setString(parameterIndex ++, request.getFromDate());
            statement.setString(parameterIndex ++, request.getToDate());
            statement.setString(parameterIndex ++, request.getCif());
            statement.setString(parameterIndex ++, request.getBranch());
            statement.setString(parameterIndex ++, request.getCrcd());
            System.out.println(statement.toString());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return statement;
    }
    public PreparedStatement acn_branch_irn_crcd_only(Connection c){
        String sql_filling = "SUM(ytd_ldgr_bal_amt_in_lc) as irnGrpYtd, SUM(dly_ldgr_bal_amt_in_lc) as irnGrpDly,crcd,boo as branch,crcd,ccob_dt from customer360.c360_depst_dtls_fact where cob_dt >= ? and cob_dt <= ? and acn = ? and boo = ? and crcd = ? and irn <= ? and irn >= ? group by acn,crcd,boo,cob_dt ";
         
        String sql_final = (this.SQL_TEMPLATE+ sql_filling);
        PreparedStatement statement = null;
        try {
            System.out.println("sc");
            statement = c.prepareStatement(sql_final);
            int parameterIndex = 1;
            statement.setString(parameterIndex ++, request.getFromDate());
            statement.setString(parameterIndex ++, request.getToDate());
            statement.setString(parameterIndex ++, request.getCif());
            statement.setString(parameterIndex ++, request.getBranch());
            statement.setString(parameterIndex ++, request.getCrcd());
            statement.setString(parameterIndex ++, request.getIrn_str());
            statement.setString(parameterIndex ++, request.getIrn_end());
            System.out.println(statement.toString());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return statement;
    }
 
public PreparedStatement SQLPrepareFinal(Connection c) {
    if (this.request.getBranch() == null) {
        if (this.request.getCrcd() == null) {
            if (this.request.getIrn_end() == null && this.request.getIrn_str() == null) {
                System.out.println("acn_only final success");
                return acn_only(c);
            } else if (this.request.getIrn_end() != null && this.request.getIrn_str() != null) {
                System.out.println("acn_irn_only final success");
                return acn_irn_only(c);
            }
        } else if (this.request.getCrcd() != null) {
            if (this.request.getIrn_end() == null && this.request.getIrn_str() == null) {
                System.out.println("acn_crcd_only final success");
                return acn_crcd_only(c);
            } else if (this.request.getIrn_end() != null && this.request.getIrn_str() != null) {
                System.out.println("acn_irn_crcd_only final success");
                return acn_irn_crcd_only(c);
            }
        }
    } else { // Branch is not null
        if (this.request.getCrcd() == null) {
            if (this.request.getIrn_end() == null && this.request.getIrn_str() == null) {
                return acn_branch_only(c);
            } else if (this.request.getIrn_end() != null && this.request.getIrn_str() != null) {
                return acn_branch_irn_only(c);
            }
        } else if (this.request.getCrcd() != null) {
            if (this.request.getIrn_end() == null && this.request.getIrn_str() == null) {
                return acn_branch_crcd_only(c);
            } else {
                return acn_branch_irn_crcd_only(c);
            }
        }
    }
    // Default case to handle paths where no condition is met
    throw new IllegalStateException("No matching conditions for SQLPrepareFinal.");
}
}

